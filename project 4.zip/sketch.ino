#include "DHT.h"


#define DHTPIN 4
#define DHTTYPE DHT22
#define LDR_PIN 32
#define PIR_PIN 13
#define ALERT_LED 5


DHT dht(DHTPIN, DHTTYPE);


void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(PIR_PIN, INPUT);
  pinMode(ALERT_LED, OUTPUT);
  Serial.println("--- SYSTEM MULTI-SENSOR IoT INTEGRATION INITIALIZED ---");
}


void loop() {
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  int ldrVal = analogRead(LDR_PIN);
  int motion = digitalRead(PIR_PIN);

  // Indikator visual jika ada gerakan / overheat
  if (motion == HIGH || temp > 35.0) {
    digitalWrite(ALERT_LED, HIGH);
  } else {
    digitalWrite(ALERT_LED, LOW);
  }

  // Format Data JSON untuk IoT Cloud Payload
  Serial.print("{\"temperature\":");
  Serial.print(temp);
  Serial.print(",\"humadity\":");
  Serial.print(hum);
  Serial.print(",\"light_adc\":");
  Serial.print(ldrVal);
  Serial.print(",\"motion_detected\":");
  Serial.print(motion ? "true":"false");
  Serial.println("}");

  delay(2000);
}