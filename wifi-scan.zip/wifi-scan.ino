const int lampu 1 = 33
const int lampu 2 = 25
const int lampu 3 = 26
const int lampu 4 = 27
const int lampu 5 = 14
const int lampu 6 = 12
const int lampu 7 = 19
const int lampu 8 = 18
const int lampu 9 = 5
const int lampu 10 = 17
const int lampu 11 = 16
const int lampu 12 = 4

void setup(){
  pinMode(lampu1, OUTPUT);
  pinMode(lampu2, OUTPUT);
  pinMode(lampu3, OUTPUT);
  pinMode(lampu4, OUTPUT);
  pinMode(lampu5, OUTPUT);
  pinMode(lampu6, OUTPUT);
  pinMode(lampu7, OUTPUT);
  pinMode(lampu8, OUTPUT);
  pinMode(lampu9, OUTPUT);
  pinMode(lampu10, OUTPUT);
  pinMode(lampu11, OUTPUT);
  pinMode(lampu12, OUTPUT);
}
void loop(){
  digitalWrite(lampu1, HIGH);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, HIGH);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, HIGH);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, HIGH);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, HIGH);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, HIGH);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, HIGH);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, HIGH);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, HIGH);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, HIGH);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, HIGH);
  digitalWrite(lampu12, LOW);
  delay(1000);

  digitalWrite(lampu1, LOW);
  digitalWrite(lampu2, LOW);
  digitalWrite(lampu3, LOW);
  digitalWrite(lampu4, LOW);
  digitalWrite(lampu5, LOW);
  digitalWrite(lampu6, LOW);
  digitalWrite(lampu7, LOW);
  digitalWrite(lampu8, LOW);
  digitalWrite(lampu9, LOW);
  digitalWrite(lampu10, LOW);
  digitalWrite(lampu11, LOW);
  digitalWrite(lampu12, HIGH);
  delay(1000);
}